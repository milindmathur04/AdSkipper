PyAV
====

Pythonic bindings for [FFmpeg][ffmpeg]/[Libav][libav].

[ffmpeg]: http://ffmpeg.org/
[libav]: http://libav.org/

[![Build Status](https://secure.travis-ci.org/mikeboers/PyAV.png?branch=master)](https://travis-ci.org/mikeboers/PyAV) [![Build status](https://ci.appveyor.com/api/projects/status/94w43xhugh6wkett?svg=true)](https://ci.appveyor.com/project/mikeboers/pyav)

Have fun, [Read the Docs](http://mikeboers.github.io/PyAV/), and good luck!
