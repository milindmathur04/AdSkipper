#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Version info"""

short_version = '1.3'
version = '1.3.2'
