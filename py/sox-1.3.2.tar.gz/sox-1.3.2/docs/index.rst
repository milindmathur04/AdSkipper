.. pysox documentation master file, created by
   sphinx-quickstart on Tue May 17 14:11:03 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pysox's documentation!
=================================

Examples
--------
.. toctree::
    :maxdepth: 3

    example

API Reference
=============
.. toctree::
   :maxdepth: 2

   api

Changes
=======
.. toctree::
   :maxdepth: 2

   changes

Contribute
==========
- `Issue Tracker <http://github.com/rabitt/pysox/issues>`_
- `Source Code <http://github.com/rabitt/pysox>`_

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


